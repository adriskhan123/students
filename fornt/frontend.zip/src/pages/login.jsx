import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
    role: "user"
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  async function handleLogin(e) {
    e.preventDefault();
    try {
      const response = await axios.post(
        "{import.meta.env.VITE_backend_base_url}/user/signupdata",
        loginData,
        {
          withCredentials: true,
        }
      );

      if (response.data.success) {
        console.log('working');

        navigate("/Projectcreate");
      }
    } catch (error) {
      console.log("Login error:", error);
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white p-6 rounded-lg shadow">
        <h1 className="text-2xl font-bold text-center mb-6">Login</h1>

        <form onSubmit={handleLogin} className="space-y-4">
          <select
            name="role"
            value={loginData.role}
            onChange={handleChange}
            className="w-full p-2 border rounded bg-white"
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>

          <input
            type="email"
            name="email"
            placeholder="Email"
            onChange={handleChange}
            className="w-full p-2 border rounded"
            required
          />
          <input
            placeholder="Password"
            className="w-full p-2 border rounded"
            required
            type="password"
            name="password"
            value={loginData.password}
            onChange={handleChange}
            autoComplete="current-password"
          />

          <button
            type="submit"
            className="w-full bg-blue-600 text-white p-2 rounded font-semibold hover:bg-blue-700"
          >
            Login
          </button>
        </form>

        <p className="text-center text-sm mt-4 text-gray-600">
          Don't have an account?{" "}
          <button
            onClick={() => navigate("/register")}
            className="text-blue-600 underline font-medium"
          >
            Register
          </button>
        </p>
      </div>
    </div>
  );
}

export default Login;