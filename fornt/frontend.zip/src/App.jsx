import React from "react";
import { Routes, Route } from "react-router-dom";

import Register from "./pages/Register";
import Login from "./pages/login";
import Projects from "./pages/projects";
import Projectcreate from "./pages/projectcreate";
import Sidebar from "./components/sidebar";

function App() {
  return (
    <div className="flex">
      <Sidebar />

      <main className="flex-1 p-8">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/projectcreate" element={<Projectcreate />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
