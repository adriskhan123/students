import React from "react";
import { Link, useLocation } from "react-router-dom";

function Sidebar() {
  const location = useLocation();

 if (location.pathname === "/" || location.pathname === "/register") {
  return null;
}

  return (
    <div className="w-64 min-h-screen bg-white border-r shadow-sm p-5">

      <div className="flex flex-col items-center mb-8">
        <img
          src="https://i.pravatar.cc/150?img=12"
          alt="Admin"
          className="w-20 h-20 rounded-full object-cover shadow"
        />

        <h2 className="mt-3 text-lg font-semibold text-gray-800">
          Admin
        </h2>
      </div>

      <div className="space-y-3">

        <Link to="/admin">
          <button className="w-full text-left px-4 py-3 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-800">
            👤 Admin
          </button>
        </Link>

        <Link to="/projects">
          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700">
            📁 Projects
          </button>
        </Link>

        <Link to="/notes">
          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700">
            📝 Notes
          </button>
        </Link>

      </div>
    </div>
  );
}

export default Sidebar;