import express from "express";
import projectsmodels from "../models/projects.models.js";
import upload from "../middleware/upload.js";

const route = express.Router();

// CREATE PROJECT
route.post("/createproject", upload.single("image"), async (req, res) => {
  try {
    const data = await projectsmodels.create({
      Projectname: req.body.Projectname,
      coustomername: req.body.coustomername,
      notes: req.body.notes,

  
      imageurl: req.file ? req.file.path : "",
    });

    return res.json({
      success: true,
      msg: "Project created successfully",
      data: data,
    });
  } catch (error) {
    console.log("Create project error:", error);

    return res.status(500).json({
      success: false,
      msg: error.message,
    });
  }
});

// FIND ALL PROJECTS
route.get("/projectsfind", async (req, res) => {
  try {
    const projectdata = await projectsmodels.find();

    return res.json({
      success: true,
      msg: "Projects found",
      project: projectdata,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      msg: error.message,
    });
  }
});

// FIND ONE PROJECT
route.post("/projectsfindone", async (req, res) => {
  try {
    const projectdata = await projectsmodels.findOne({
      _id: req.body.id,
    });

    if (!projectdata) {
      return res.json({
        success: false,
        msg: "Project not found",
      });
    }

    return res.json({
      success: true,
      msg: "Project found",
      project: projectdata,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      msg: error.message,
    });
  }
});

// DELETE PROJECT
route.post("/projectdelete", async (req, res) => {
  try {
    const deleted = await projectsmodels.findByIdAndDelete(req.body.id);

    if (!deleted) {
      return res.json({
        success: false,
        msg: "Project not found",
      });
    }

    return res.json({
      success: true,
      msg: "Project deleted successfully",
      data: deleted,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      msg: error.message,
    });
  }
});

export default route;