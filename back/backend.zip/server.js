import express from "express";
import cors from "cors";
import dpconnection from "./dp/dpconnection.js";
import userroute from "./route/user.route.js";
import projectsroute from "./route/projects.route.js";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";

dotenv.config();

const app = express();

app.use(cookieParser());

dpconnection();

app.use(
  cors({
    origin: process.env.forntend_url,
    credentials: true,
  })
);

app.use(express.json());

app.use("/user", userroute);
app.use("/projects", projectsroute);

app.listen(process.env.PORT || 3000, () => {
  console.log("Server running on port 3000");
});